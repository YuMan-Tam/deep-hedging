import pyqtgraph as pg
from pyqtgraph.widgets.RemoteGraphicsView import RemoteGraphicsView
import numpy as np

app = pg.mkQApp()

view = RemoteGraphicsView()
view_1 = RemoteGraphicsView()

plotitem = view.pg.PlotItem()
view.setCentralItem(plotitem)

x = np.random.normal(size=1000)
y = np.random.normal(size=1000)

bargraph = view.pg.PlotDataItem()
bargraph.setPen(color ="r", width=2.5)
bargraph.setData(x,y)
plotitem.addItem(bargraph)

view.show()

plotitem_1 = view_1.pg.PlotItem()
view_1.setCentralItem(plotitem_1)

bargraph_1 = view_1.pg.PlotDataItem()
bargraph_1.setPen(color ="r", width=2.5)
bargraph_1.setData(x,y)
plotitem_1.addItem(bargraph_1)

view_1.show()