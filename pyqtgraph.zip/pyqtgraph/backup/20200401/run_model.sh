# By Yu-Man Tam: 1/7/2020

# Command to run:
# bsub -Is -q "python"  numactl -C 0 zsh run_model.sh
# bsub -Is -q "python"  numactl --cpunodebind=0 zsh run_model.sh
# numactl --cpunodebind=0 jupyter notebook --NotebookApp.allow_origin='https://colab.research.google.com' --port=8889 --NotebookApp.port_retries=0 --no-browser

# 1/7/2020: This line removes the default LD_LIBRARY_PATH and updates it with my own MKL library path. 
# It is needed because, for now, LSF does not transfer this variable from the host environment to the 
# execution environment. 
export LD_LIBRARY_PATH="$HOME/.local/intel/compilers_and_libraries_2019/linux/mkl/lib/intel64"

# Run the main model script here.
python3 # Need to run exec(open("deep_hedging_demo.py").read())
# python3 deep_hedging_demo.py
