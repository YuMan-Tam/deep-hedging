import pyqtgraph as pg
from pyqtgraph.Qt import QtCore, QtGui
import numpy as np

win = pg.GraphicsWindow()
win.resize(800,350)
win.setWindowTitle('pyqtgraph example: Histogram')
plt1 = win.addPlot()

win = pg.plot()
## make interesting distribution of values
vals_1 = np.hstack([np.random.normal(size=500), np.random.normal(size=260, loc=4)])
vals_2 = np.hstack([np.random.normal(size=500), np.random.normal(size=260, loc=4)])
## compute standard histogram
y1,x1 = np.histogram(vals_1, bins=np.linspace(-3, 8, 40))
y2,x2 = np.histogram(vals_2, bins=np.linspace(-3, 8, 40))

## Using stepMode=True causes the plot to draw two lines for each sample.
## notice that len(x) == len(y)+1
# plt1.plot(x1,y1, stepMode=True, fillLevel=0, brush=(0,0,255,150))
# plt1.plot(x1, y1, stepMode=True, fillLevel=0, brush=(0,0,255,50))
# plt1.plot(x2, y2, stepMode=True, fillLevel=0, brush=(0,255,0,50))
bg1 = pg.BarGraphItem(x=x1[1:], height=y1, width=0.3, brush='r')
bg2 = pg.BarGraphItem(x=x2[1:]+0.33, height=y2, width=0.3, brush='b')
win.addItem(bg1)
win.addItem(bg2)

win = pg.plot()
win.setWindowTitle('pyqtgraph example: BarGraphItem')

x = np.arange(10)
y1 = np.sin(x)
y2 = 1.1 * np.sin(x+1)
y3 = 1.2 * np.sin(x+2)

bg1 = pg.BarGraphItem(x=x, height=y1, width=0.3, brush='r')
bg2 = pg.BarGraphItem(x=x+0.33, height=y2, width=0.3, brush='g')
bg3 = pg.BarGraphItem(x=x+0.66, height=y3, width=0.3, brush='b')

win.addItem(bg1)
win.addItem(bg2)
win.addItem(bg3)
