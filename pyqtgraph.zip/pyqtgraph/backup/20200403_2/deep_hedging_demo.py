# Commented out IPython magic to ensure Python compatibility.
#@title <font color='Blue'>**Overheads**</font>

# Author: Yu-Man Tam
# Last updated: 3/3/2020

# Reference: Deep Hedging (2019, Quantitative Finance) by Buehler et al.
# https://www.tandfonline.com/doi/abs/10.1080/14697688.2019.1571683

import sys, os
sys.path.insert(0, os.getcwd() + "/lib/qt")
sys.path.insert(0, os.getcwd() + "/lib")

# Linear algebra, finance, and machine learning libraries
import numpy as np
import QuantLib as ql
import tensorflow as tf

from tensorflow.keras.optimizers import Adam

# For PyQtgraph
import pyqtgraph as pg
from pyqtgraph.Qt import QtCore, QtGui

# User-defined libraries
from stochastic_processes import BlackScholesProcess
from instruments import European_Call
from deep_hedging import Deep_Hedging_Model
from loss_metrics import Entropy, CVaR
from utilities import train_test_split

# Tensorflow settings
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

# %load_ext autoreload

print("\nFinish loading all necessary libraries!\n")

"""**Import all neccessary python, quantitative finance, and machine learning software libraries.**"""

#@title <font color='Blue'>**User Inputs**</font>

# Geometric Brownian Motion.
N = 30 # Number of time steps (in days)

S0 = 100.0 # Stock price at time = 0
sigma = 0.2 # Implied volatility
risk_free = 0.0 # Risk-free rate
dividend = 0.0 # Continuous dividend yield

Ktrain = 1*(10**5) # Size of training sample.
Ktest_ratio = 0.2 # Fraction of training sample as testing sample.

# European call option (short).
strike = S0
payoff_func = lambda x: -np.maximum(x - strike, 0.0)
calculation_date = ql.Date.todaysDate()
maturity_date = ql.Date.todaysDate() + N

# Day convention.
day_count = ql.Actual365Fixed() # Actual/Actual (ISDA)

# Proportional transaction cost.
epsilon = np.power(2.0,-8)*0.0                 

# Information set (in string)
# Choose from: S, log_S, normalized_log_S (by S0)
information_set = "normalized_log_S"

# Loss function
# loss_type = "CVaR" (Expected Shortfall) -> loss_param = alpha 
# loss_type = "Entropy" -> loss_param = lambda
loss_type = "Entropy"
loss_param = 1.0

# Neural network (NN) structure
m = 15 # Number of neurons in each hidden layer.
d = 3 # Number of hidden layers (Note including input nor output layer)         

# Other NN parameters
lr = 1e-2 # Learning rate
batch_size=256 # Batch size
epochs=50 # Number of epochs

use_batch_norm = False
kernel_initializer = "he_uniform"

activation_dense = "leaky_relu"
activation_output = "sigmoid"
final_period_cost = False

# Other control flags for development purpose.
mc_simulator = "QuantLib" # "QuantLib" or "Numpy"

flag_load_simulation_data = True

# Plot parameters
num_bin = 30

# Output directories
simulation_data_dir = "./data/"

print("Finish loading all user inputs!\n")

"""**Provide input parameters for Monte Carlo simulation, call option, transaction cost, loss function, and deep hedging algorithm.**"""

#@title <font color='Blue'>**Monte Carlo Simulation - Generate Random Paths of Stock Prices**</font>

# Create a directory if the output directories do not exist.
try:
	os.makedirs(simulation_data_dir)
except:
	pass
		
# Length of one time-step (as fraction of a year).
nobs = int(Ktrain*(1+Ktest_ratio)) # Training + Testing

dt = day_count.yearFraction(calculation_date,calculation_date + 1) 
maturity = N*dt # Maturities (in the unit of a year)

stochastic_process = BlackScholesProcess(s0 = S0, sigma = sigma, \
                      risk_free = risk_free, dividend = dividend, day_count=day_count)

simulation_data_file = simulation_data_dir +"stock_" + str(int(np.log10(Ktrain))) + ".npy"
if not flag_load_simulation_data:
	if mc_simulator is "QuantLib":
		S = stochastic_process.gen_path(maturity, N, nobs)
	elif mc_simulator is "Numpy":
		# Only for geometric Brownian motion
		randn = (risk_free - dividend - sigma ** 2 / 2.0) * dt + \
								sigma * np.random.normal(0, np.sqrt(dt), size=(nobs, N))
		S = np.hstack((np.ones((nobs,1))*np.log(S0),randn))
		S = np.exp(np.cumsum(S,axis=1))
		
	np.save(simulation_data_file, S)
else:	
	try:
	  print("Check if there is usable data from previous simulation...\n")
	  S = np.load(simulation_data_file)
	  print("Successfully loaded data!!!\n")
	except:
		print("There is no simulation data!!!")

#@title <font color='Blue'>**Prepare data to be fed into the deep hedging algorithm.**</font>
payoff_T = payoff_func(S[:,-1]) # Payoff of the call option

trade_set =  np.stack((S),axis=1) # Trading set

if information_set is "S":
  I =  np.stack((S),axis=1) # Information set
elif information_set is "log_S":
  I =  np.stack((np.log(S)),axis=1)
elif information_set is "normalized_log_S":
	I =  np.stack((np.log(S/S0)),axis=1)
	
# Structure of xtrain:
#   1) Trade set: [S]
#   2) Information set: [S] 
#   3) payoff (dim = 1)
x_all = []
for i in range(N+1):
	x_all += [trade_set[i,:,None]]
	if i != N:
		x_all += [I[i,:,None]]
x_all += [payoff_T[:,None]]

# Split the entire sample into a training sample and a testing sample.
test_size = int(Ktrain*Ktest_ratio)
[xtrain, xtest] = train_test_split(x_all, test_size=test_size)
[S_train, S_test] = train_test_split([S], test_size=test_size)
[option_payoff_train, option_payoff_test] = \
    train_test_split([x_all[-1]], test_size=test_size)

# Convert the training sample into tf.Data format (same as xtrain).
training_dataset = tf.data.Dataset.from_tensor_slices(tuple(xtrain))
training_dataset = training_dataset.cache()

# Obtain Black-Scholes price, delta, and PnL
call = European_Call()
price_BS = call.get_BS_price(S = S_test[0], sigma = sigma, risk_free = risk_free, \
									dividend = dividend, K = strike, exercise_date = maturity_date, \
									calculation_date = calculation_date, day_count = day_count, dt = dt)
delta_BS = call.get_BS_delta(S = S_test[0], sigma = sigma, risk_free = risk_free, \
									dividend = dividend, K = strike, exercise_date = maturity_date, \
									calculation_date = calculation_date, day_count = day_count, dt = dt)
PnL_BS =  call.get_BS_PnL(S=S_test[0], payoff=payoff_func(S_test[0][:,-1]), \
                  delta=delta_BS, dt=dt, risk_free = risk_free, \
									final_period_cost=final_period_cost, epsilon=epsilon)

print("Finish preparing training and testing data!")

# Commented out IPython magic to ensure Python compatibility.
# @title <font color='Blue'>**Run the Deep Hedging Algorithm (Simple Network)!**</font>
# %autoreload 2
strategy_type = "simple"
optimizer = Adam(learning_rate=lr)

# Setup and compile the model
model_simple = Deep_Hedging_Model(N=N, d=d+2, m=m, risk_free=risk_free, \
                      dt = dt, strategy_type=strategy_type, epsilon = epsilon, \
											use_batch_norm = use_batch_norm, kernel_initializer = kernel_initializer, \
											activation_dense = activation_dense, activation_output = activation_output, \
											final_period_cost = final_period_cost)
# Accelerate the code using tf.function. 
model_simple_func = tf.function(model_simple)

# Plot live graph.

## Always start by initializing Qt (only once per application)
app = QtGui.QApplication([])

fig_PnL = pg.plot()
fig_PnL.setWindowTitle("Black-Scholes PnL v.s. Deep Hedging PnL")

x_range = (PnL_BS.min()+price_BS[0,0], PnL_BS.max()+price_BS[0,0])
BS_bins, bin_edges = np.histogram(PnL_BS+price_BS[0,0], bins = num_bin, range = x_range)
width = (bin_edges[1] - bin_edges[0])/2.0

BS_hist = pg.BarGraphItem(x=bin_edges[:-2], height=BS_bins, width=width, brush='r')
fig_PnL.addItem(BS_hist)

# Certainty equivalent as defined in Buehler's paper. 
certainty_equiv = tf.Variable(0.0)

num_epoch = 0
num_batch = 0
def update():
	global mini_batch_iter, DH_hist, certainty_equiv, wealth, loss_param, \
					xtest, price_BS, num_bin, x_range, num_batch, fig_PnL, \
					grads, optimizer, training_dataset, Ktrain, batch_size, num_epoch
	try:
		mini_batch = mini_batch_iter.next()
	except:
		num_batch = 0
		num_epoch += 1 
		mini_batch_iter = training_dataset.shuffle(Ktrain).batch(batch_size).__iter__()
		mini_batch = mini_batch_iter.next()
	
	num_batch += 1
	
	# Record gradient
	with tf.GradientTape() as tape:
		wealth = model_simple_func(mini_batch)
		loss = Entropy(wealth, certainty_equiv, loss_param)
	
	PnL_DH = model_simple_func(xtest).numpy().squeeze()
	DH_bins, bin_edges = np.histogram(PnL_DH+price_BS[0,0], bins = num_bin, range = x_range)
	
	# Forward and backward passes
	grads = tape.gradient(loss, model_simple.trainable_weights)
	optimizer.apply_gradients(zip(grads, model_simple.trainable_weights))
	
	if num_epoch == 1 and num_batch == 1:
		DH_hist = pg.BarGraphItem(x=bin_edges[:-2]+width, height=DH_bins, width=width, brush='b')
		fig_PnL.addItem(DH_hist)
	else:
		DH_hist.setOpts(height=DH_bins)
	
	print((loss.numpy(),num_epoch,num_batch))

timer = QtCore.QTimer()
timer.timeout.connect(update)
timer.start(0)		
	
# # Start Qt event loop unless running in interactive mode or using pyside.
# if __name__ == '__main__':
    # import sys
    # if sys.flags.interactive != 1 or not hasattr(QtCore, 'PYQT_VERSION'):
        # pg.QtGui.QApplication.exec_()
