# Commented out IPython magic to ensure Python compatibility.
#@title <font color='Blue'>**Overheads**</font>

# Author: Yu-Man Tam
# Last updated: 3/3/2020

# Reference: Deep Hedging (2019, Quantitative Finance) by Buehler et al.
# https://www.tandfonline.com/doi/abs/10.1080/14697688.2019.1571683

# Qt references: https://doc.qt.io/qt-5/qmainwindow.html

import sys, os
sys.path.insert(0, os.getcwd() + "/lib/qt")
sys.path.insert(0, os.getcwd() + "/lib")

# Linear algebra, finance, and machine learning libraries
import numpy as np
import QuantLib as ql
import tensorflow as tf

from tensorflow.keras.optimizers import Adam

# For PyQtgraph
import pyqtgraph as pg
from pyqtgraph.Qt import QtWidgets,QtCore, QtGui
from pyqtgraph.parametertree import ParameterTree, Parameter

# User-defined libraries
from stochastic_processes import BlackScholesProcess
from instruments import European_Call
from deep_hedging import Deep_Hedging_Model
from loss_metrics import Entropy, CVaR
from utilities import train_test_split
from default_params import Deep_Hedging_Params

# Tensorflow settings
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

# Default Parameters
# European call option (short).
payoff_func = lambda x: -np.maximum(x - strike, 0.0)
calculation_date = ql.Date.todaysDate()

# Day convention.
day_count = ql.Actual365Fixed() # Actual/Actual (ISDA)         

# Information set (in string)
# Choose from: S, log_S, normalized_log_S (by S0)
information_set = "normalized_log_S"

# Loss function
# loss_type = "CVaR" (Expected Shortfall) -> loss_param = alpha 
# loss_type = "Entropy" -> loss_param = lambda
loss_type = "Entropy"

# Other NN parameters
use_batch_norm = False
kernel_initializer = "he_uniform"

activation_dense = "leaky_relu"
activation_output = "sigmoid"
final_period_cost = False

# Number of bins to plot for the PnL histograms.
num_bins = 30

class MainWindow(QtWidgets.QMainWindow):
	def __init__(self, *args, **kwargs):
		# Inheritance from the QMainWindow class
		# Reference: https://doc.qt.io/qt-5/qmainwindow.html
		super(MainWindow, self).__init__(*args, **kwargs)
		
		# Define central widget.
		## Define a top-level widget to hold everything
		w = QtGui.QWidget()

		## Create some widgets to be placed inside
		btn = QtGui.QPushButton('press me')
		
		## Create a grid layout to manage the widgets size and position
		layout = QtGui.QGridLayout()
		w.setLayout(layout)
		
		self.setCentralWidget(w)
		
		# Add the parameter menu.
		tree = self.Deep_Hedging_Parameter_Widget()
		layout.addWidget(tree, 1, 0, 1, 1)   # button goes in upper-left
		
		# Simulate the stock price process.
		self.S = self.simulate_stock_prices()
		
		# Assemble the dataset for training and testing.
		# Structure of data:
		#   1) Trade set: [S]
		#   2) Information set: [S] 
		#   3) payoff (dim = 1)
		self.training_dataset = self.assemble_data()

		# Compute Black-Scholes prices for benchmarking.
		self.price_BS, self.delta_BS, self.PnL_BS = self.get_Black_Scholes_Prices()
		
		# Add the PnL histogram (PlotWidget) - Black-Scholes vs Deep Hedging.
		self.fig_PnL = self.PnL_Hist_Widget()
		
		layout.addWidget(self.fig_PnL, 1, 1, 1, 1)  # plot goes on right side, spanning 3 rows
	
	def Deep_Hedging_Parameter_Widget(self):
		tree = ParameterTree()
		
		## Create tree of Parameter objects
		self.params = Parameter.create(name='params', type='group', children=Deep_Hedging_Params())
		tree.setParameters(self.params, showTop=False)
		
		self.Ktrain = self.params.param("Deep Hedging Strategy", 'Sample Size', "Training").value()
		self.Ktest_ratio = self.params.param("Deep Hedging Strategy", 'Sample Size', "Testing (as fraction of Training)").value()
		self.N = self.params.param("European Call", "Maturity (in days)").value()
		self.S0 = self.params.param("European Call", "S0").value()
		self.strike = self.params.param("European Call", "Strike").value()
		self.sigma = self.params.param("European Call", "Implied Volatility").value()
		self.risk_free = self.params.param("European Call", "Risk-Free Rate").value()
		self.dividend = self.params.param("European Call", "Dividend Yield").value()
		
		self.loss_param = self.params.param("Deep Hedging Strategy", 'Loss Function', "Risk Aversion").value()
		self.epsilon = self.params.param("European Call", "Proportional Transaction Cost", "Cost").value()
		self.d = self.params.param("Deep Hedging Strategy", "Network Structure", "Number of Layers").value()
		self.m = self.params.param("Deep Hedging Strategy", "Network Structure", "Number of Neurons").value()
		self.strategy_type = self.params.param("Deep Hedging Strategy", "Network Structure", "Network Type").value()
		
		self.lr = self.params.param("Deep Hedging Strategy", "Learning Parameters", "Learning Rate").value()
		self.batch_size = self.params.param("Deep Hedging Strategy", "Learning Parameters", "Size of Mini-Batch").value()
		self.epochs = self.params.param("Deep Hedging Strategy", "Learning Parameters", "Number of Epochs").value()
		
		self.maturity_date = calculation_date + self.N
		self.payoff_func = lambda x: -np.maximum(x - self.strike, 0.0)
		
		return tree
		
	# Draw PnL histogram (PlotWidget) - Black-Scholes vs Deep Hedging.
	def PnL_Hist_Widget(self):
		self.optimizer = Adam(learning_rate=self.lr)

		# Setup and compile the model
		self.model = Deep_Hedging_Model(N=self.N, d=self.d+2, m=self.m, risk_free=self.risk_free, \
													dt = self.dt, strategy_type=self.strategy_type, epsilon = self.epsilon, \
													use_batch_norm = use_batch_norm, kernel_initializer = kernel_initializer, \
													activation_dense = activation_dense, activation_output = activation_output, \
													final_period_cost = final_period_cost)
		# Accelerate the code using tf.function. 
		self.model_func = tf.function(self.model)

		# Initialize the PnL Histogram Widget.
		fig_PnL = pg.PlotWidget()
		fig_PnL.setWindowTitle("Black-Scholes PnL v.s. Deep Hedging PnL")

		self.x_range = (self.PnL_BS.min()+self.price_BS[0,0], self.PnL_BS.max()+self.price_BS[0,0])
		self.BS_bins, self.bin_edges = np.histogram(self.PnL_BS+self.price_BS[0,0], bins = num_bins, range = self.x_range)
		self.width = (self.bin_edges[1] - self.bin_edges[0])/2.0

		self.BS_hist = pg.BarGraphItem(x=self.bin_edges[:-2], height=self.BS_bins, width=self.width, brush='r')
		fig_PnL.addItem(self.BS_hist)
		
		self.certainty_equiv = tf.Variable(0.0)
		
		self.mini_batch = 0
		self.num_epoch = 0
		
		return fig_PnL

	# Live update for the PnL_Hist_Widget.
	def update_PnL_Hist_Widget(self):
		try:
			mini_batch = self.mini_batch_iter.next()
		except:
			self.num_batch = 0
			self.num_epoch += 1 
			
			self.mini_batch_iter = self.training_dataset.shuffle(self.Ktrain).batch(self.batch_size).__iter__()
			mini_batch = self.mini_batch_iter.next()
		
		self.num_batch += 1
		
		# Record gradient
		with tf.GradientTape() as tape:
			wealth =self.model_func(mini_batch)
			loss = Entropy(wealth, self.certainty_equiv, self.loss_param)
		
		PnL_DH = self.model_func(self.xtest).numpy().squeeze()
		DH_bins, bin_edges = np.histogram(PnL_DH+self.price_BS[0,0], bins = num_bins, range = self.x_range)
		
		# Forward and backward passes
		self.grads = tape.gradient(loss, self.model.trainable_weights)
		self.optimizer.apply_gradients(zip(self.grads, self.model.trainable_weights))
		
		if self.num_epoch == 1 and self.num_batch == 1:
			self.DH_hist = pg.BarGraphItem(x=bin_edges[:-2]+self.width, height=DH_bins, width=self.width, brush='b')
			self.fig_PnL.addItem(self.DH_hist)
		else:
			self.DH_hist.setOpts(height=DH_bins)
		
		print((loss.numpy(),self.num_epoch,self.num_batch))
		
	def simulate_stock_prices(self):
		self.nobs = int(self.Ktrain*(1+self.Ktest_ratio)) # Total obs = Training + Testing
		
		# Length of one time-step (as fraction of a year).
		self.dt = day_count.yearFraction(calculation_date,calculation_date + 1) 
		self.maturity = self.N*self.dt # Maturities (in the unit of a year)

		self.stochastic_process = BlackScholesProcess(s0 = self.S0, sigma = self.sigma, \
													risk_free = self.risk_free, dividend = self.dividend, day_count=day_count)
													
		print("\nRun Monte-Carlo Simulations for the Stock Price Process.\n")
		return self.stochastic_process.gen_path(self.maturity, self.N, self.nobs)
		
	def assemble_data(self):
		self.payoff_T = self.payoff_func(self.S[:,-1]) # Payoff of the call option

		self.trade_set =  np.stack((self.S),axis=1) # Trading set

		if information_set is "S":
			self.I =  np.stack((self.S),axis=1) # Information set
		elif information_set is "log_S":
			self.I =  np.stack((np.log(self.S)),axis=1)
		elif information_set is "normalized_log_S":
			self.I =  np.stack((np.log(self.S/self.S0)),axis=1)
			
		# Structure of xtrain:
		#   1) Trade set: [S]
		#   2) Information set: [S] 
		#   3) payoff (dim = 1)
		self.x_all = []
		for i in range(self.N+1):
			self.x_all += [self.trade_set[i,:,None]]
			if i != self.N:
				self.x_all += [self.I[i,:,None]]
		self.x_all += [self.payoff_T[:,None]]

		# Split the entire sample into a training sample and a testing sample.
		self.test_size = int(self.Ktrain*self.Ktest_ratio)
		[self.xtrain, self.xtest] = train_test_split(self.x_all, test_size=self.test_size)
		[self.S_train, self.S_test] = train_test_split([self.S], test_size=self.test_size)
		[self.option_payoff_train, self.option_payoff_test] = \
				train_test_split([self.x_all[-1]], test_size=self.test_size)

		# Convert the training sample into tf.Data format (same as xtrain).
		training_dataset = tf.data.Dataset.from_tensor_slices(tuple(self.xtrain))
		return training_dataset.cache()
		
	def get_Black_Scholes_Prices(self):
		# Obtain Black-Scholes price, delta, and PnL
		call = European_Call()
		price_BS = call.get_BS_price(S = self.S_test[0], sigma = self.sigma, risk_free = self.risk_free, \
											dividend = self.dividend, K = self.strike, exercise_date = self.maturity_date, \
											calculation_date = calculation_date, day_count = day_count, dt = self.dt)
		delta_BS = call.get_BS_delta(S = self.S_test[0], sigma = self.sigma, risk_free = self.risk_free, \
											dividend = self.dividend, K = self.strike, exercise_date = self.maturity_date, \
											calculation_date = calculation_date, day_count = day_count, dt = self.dt)
		PnL_BS =  call.get_BS_PnL(S= self.S_test[0], payoff=self.payoff_func(self.S_test[0][:,-1]), \
											delta=delta_BS, dt=self.dt, risk_free = self.risk_free, \
											final_period_cost=final_period_cost, epsilon=self.epsilon)
		return price_BS, delta_BS, PnL_BS
		
if __name__ == '__main__':
	app = QtWidgets.QApplication(sys.argv)
	main = MainWindow()
	main.show()
	
	# Live graph update.
	timer = QtCore.QTimer()
	timer.timeout.connect(main.update_PnL_Hist_Widget)
	timer.start(0)	

	# sys.exit(app.exec_())